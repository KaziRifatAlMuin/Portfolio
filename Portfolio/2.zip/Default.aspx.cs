using System;
using System.Web.UI;

namespace PortfolioWebForms
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Logic to load data if needed (e.g., fetch user data, track visits)
        }
    }
}
