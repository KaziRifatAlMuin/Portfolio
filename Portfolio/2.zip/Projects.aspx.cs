using System;
using System.Web.UI;

namespace PortfolioWebForms
{
    public partial class Projects : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Logic to dynamically load project data if needed
        }
    }
}
