using System;
using System.Web.UI;

namespace PortfolioWebForms
{
    public partial class SiteMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Your code for handling the master page logic
        }
    }
}
