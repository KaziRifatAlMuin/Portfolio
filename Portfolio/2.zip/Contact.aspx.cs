using System;
using System.Net;
using System.Net.Mail;
using System.Web.UI;
using System.Xml.Linq;

namespace PortfolioWebForms
{
    public partial class Contact : Page
    {
        // Event handler for the Send Message button
        protected void btnSend_Click(object sender, EventArgs e)
        {
            // Get values from controls
            string name = txtName?.Text.Trim();
            string email = txtEmail?.Text.Trim();
            string message = txtMessage?.Text.Trim();

            // Validate inputs
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(message))
            {
                lblResult.Text = "Please fill out all fields.";
                lblResult.CssClass = "text-danger";
                return;
            }

            try
            {
                // Sender and recipient email addresses
                var fromAddress = new MailAddress("youremail@gmail.com", "Portfolio Contact");
                var toAddress = new MailAddress("youremail@gmail.com");

                using (var mail = new MailMessage())
                {
                    mail.From = fromAddress;
                    mail.To.Add(toAddress);
                    if (!string.IsNullOrEmpty(email))
                        mail.ReplyToList.Add(new MailAddress(email));

                    mail.Subject = $"Message from {name}";
                    mail.Body = $"<p><strong>Name:</strong> {System.Web.HttpUtility.HtmlEncode(name)}</p>" +
                                $"<p><strong>Email:</strong> {System.Web.HttpUtility.HtmlEncode(email)}</p>" +
                                $"<p><strong>Message:</strong><br/>{System.Web.HttpUtility.HtmlEncode(message).Replace(Environment.NewLine, "<br/>")}</p>";
                    mail.IsBodyHtml = true;

                    // SMTP client to send the email
                    using (var smtpClient = new SmtpClient("smtp.gmail.com", 587))
                    {
                        smtpClient.Credentials = new NetworkCredential("youremail@gmail.com", "yourpassword"); // Replace with your email credentials
                        smtpClient.EnableSsl = true;
                        smtpClient.Send(mail);
                    }
                }

                // If email is sent successfully
                lblResult.Text = "Message sent successfully!";
                lblResult.CssClass = "text-success";
            }
            catch (Exception)
            {
                // If email sending fails
                lblResult.Text = "Failed to send message. Please try again later.";
                lblResult.CssClass = "text-danger";
            }
        }
    }
}
