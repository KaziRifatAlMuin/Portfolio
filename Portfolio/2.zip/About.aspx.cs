using System;
using System.Web.UI;

namespace PortfolioWebForms
{
    public partial class About : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Logic to load any specific data for About Me section
        }
    }
}
